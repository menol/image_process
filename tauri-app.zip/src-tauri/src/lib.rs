// Learn more about Tauri commands at https://tauri.app/develop/calling-rust/
use serde::{Serialize, Deserialize};
use image::{ImageFormat, GenericImageView, DynamicImage};
use std::io::Cursor;
use base64::{Engine as _, engine::general_purpose};
use rayon::prelude::*;
use rayon::iter::IntoParallelRefIterator;
use std::sync::Arc;

// 图片处理选项结构体
#[derive(Serialize, Deserialize, Clone)]
pub struct ImageOptions {
    pub quality: u8,        // 压缩质量 (0-100)
    pub format: String,     // 输出格式 ("jpeg", "png", "gif", "webp")
    pub max_width: Option<u32>,  // 最大宽度
    pub max_height: Option<u32>, // 最大高度
    pub optimize: bool,     // 是否进行优化
    pub strip_metadata: bool, // 是否移除元数据
    pub progressive: bool,  // 是否使用渐进式JPEG
}

// 处理结果结构体
#[derive(Serialize, Clone)]
pub struct ProcessResult {
    data: String,           // base64编码的图片数据
    format: String,         // 图片格式
    size: u32,             // 图片大小(字节)
    width: u32,            // 图片宽度
    height: u32,           // 图片高度
}

// 批量处理结果结构体
#[derive(Serialize, Clone)]
pub struct BatchProcessResult {
    results: Vec<ProcessResult>,  // 处理结果列表
    success_count: usize,         // 成功处理的图片数量
    failed_count: usize,          // 处理失败的图片数量
}

// 错误处理枚举
#[derive(Debug)]
enum ImageProcessError {
    DecodeError(String),
    EncodeError(String),
    InvalidFormat(String),
    IoError(String),
}

#[derive(Serialize)]
struct Progress {
    current: usize,
    total: usize,
    percentage: f32,
}

// 1. 添加文件大小限制
const MAX_FILE_SIZE: usize = 50 * 1024 * 1024; // 50MB

// 2. 添加文件类型验证
fn validate_image_format(data: &[u8]) -> bool {
    match image::guess_format(data) {
        Ok(format) => matches!(format, 
            ImageFormat::Jpeg | 
            ImageFormat::Png | 
            ImageFormat::Gif | 
            ImageFormat::WebP
        ),
        Err(_) => false,
    }
}

// 3. 添加错误处理和日志记录
fn process_with_logging(data: &[u8]) -> Result<ProcessResult, ImageProcessError> {
    println!("开始处理图片，大小: {} bytes", data.len());
    
    if !validate_image_format(data) {
        println!("不支持的图片格式");
        return Err(ImageProcessError::InvalidFormat("不支持的格式".into()));
    }
    
    // 处理逻辑...
    Err(ImageProcessError::IoError("未实现".into()))
}

#[tauri::command]
// 处理多个图片数据的核心函数
async fn app_process_image(base64_data_list: Vec<String>, options_json: String) -> Result<BatchProcessResult, String> {
    let options: ImageOptions = match serde_json::from_str(&options_json) {
        Ok(opts) => opts,
        Err(e) => return Err(format!("解析选项失败: {}", e)),
    };
    
    // 使用rayon并行处理所有图片
    let results: Vec<_> = base64_data_list.par_iter()
        .map(|base64_data| process_single_image(base64_data.clone(), options.clone()))
        .collect();
    
    // 统计处理结果
    let mut success_results = Vec::new();
    let mut failed_count = 0;
    
    for result in results {
        match result {
            Ok(process_result) => success_results.push(process_result),
            Err(_) => failed_count += 1,
        }
    }
    
    // 避免不必要的clone
    Ok(BatchProcessResult {
        results: success_results.clone(),
        success_count: success_results.len(),
        failed_count,
    })
}

// 移除图片元数据的函数实现 - 移除不存在的变体
fn strip_metadata(img: DynamicImage) -> DynamicImage {
    // 获取图像尺寸和格式
    let (width, height) = img.dimensions();
    
    // 根据图像类型创建对应格式的新图像
    match img {
        DynamicImage::ImageRgb8(_) => {
            // 复制RGB8图像数据到新图像
            let rgb_data = img.to_rgb8();
            DynamicImage::ImageRgb8(rgb_data)
        },
        DynamicImage::ImageRgba8(_) => {
            // 复制RGBA8图像数据到新图像
            let rgba_data = img.to_rgba8();
            DynamicImage::ImageRgba8(rgba_data)
        },
        DynamicImage::ImageLuma8(_) => {
            // 复制灰度图像数据到新图像
            let luma_data = img.to_luma8();
            DynamicImage::ImageLuma8(luma_data)
        },
        DynamicImage::ImageLumaA8(_) => {
            // 复制带Alpha通道的灰度图像数据到新图像
            let luma_alpha_data = img.to_luma_alpha8();
            DynamicImage::ImageLumaA8(luma_alpha_data)
        },
        // 移除不支持的变体，用通用处理替代
        _ => {
            // 对于其他类型，转换为RGBA8格式
            let rgba_data = img.to_rgba8();
            DynamicImage::ImageRgba8(rgba_data)
        }
    }
}

// 改进函数 - 计算最佳质量
fn calculate_optimal_quality(img: &DynamicImage) -> u8 {
    // 获取图像尺寸和像素数量
    let (width, height) = img.dimensions();
    let pixel_count = width * height;
    
    // 分析图像复杂度
    let complexity = calculate_image_complexity(img);
    
    // 根据图像尺寸和复杂度动态调整质量
    let base_quality = if pixel_count > 2_000_000 {
        // 大图像可以使用较低质量
        75
    } else if pixel_count < 500_000 {
        // 小图像需要较高质量
        90
    } else {
        // 中等尺寸图像
        82
    };
    
    // 根据复杂度调整基础质量
    let adjusted_quality = match complexity {
        ImageComplexity::High => base_quality + 8,    // 复杂图像需要更高质量
        ImageComplexity::Medium => base_quality + 3,  // 中等复杂度
        ImageComplexity::Low => base_quality - 5,     // 简单图像可以用更低质量
    };
    
    // 确保质量在合理范围内
    adjusted_quality.clamp(65, 95)
}

// 图像复杂度枚举
enum ImageComplexity {
    Low,     // 简单图像，如logo、图标、简单图形
    Medium,  // 中等复杂度，如插图、简单照片
    High,    // 高复杂度，如细节丰富的照片、纹理
}

// 分析图像复杂度
fn calculate_image_complexity(img: &DynamicImage) -> ImageComplexity {
    // 转换为灰度图像用于分析
    let gray_img = img.grayscale();
    
    // 计算边缘密度作为复杂度指标
    let edges = edge_detection(&gray_img);
    
    // 计算颜色多样性
    let color_diversity = calculate_color_diversity(img);
    
    // 综合考虑边缘密度和颜色多样性
    if edges > 0.15 || color_diversity > 0.7 {
        ImageComplexity::High
    } else if edges > 0.08 || color_diversity > 0.4 {
        ImageComplexity::Medium
    } else {
        ImageComplexity::Low
    }
}

// 边缘检测函数
fn edge_detection(gray_img: &DynamicImage) -> f32 {
    // 简化实现：使用简单的梯度差分来检测边缘
    let (width, height) = gray_img.dimensions();
    if width < 3 || height < 3 {
        return 0.0;
    }
    
    // 计算边缘像素数量
    let mut edge_pixels = 0;
    let img_buffer = gray_img.to_luma8();
    
    // 采样图像的子集来提高性能 - 修复类型
    let sample_rate = if width * height > 1_000_000 { 5usize } else { 2usize };
    
    for y in (sample_rate..(height as usize)-sample_rate).step_by(sample_rate) {
        for x in (sample_rate..(width as usize)-sample_rate).step_by(sample_rate) {
            let center = img_buffer.get_pixel(x as u32, y as u32).0[0] as i32;
            let left = img_buffer.get_pixel((x-sample_rate) as u32, y as u32).0[0] as i32;
            let right = img_buffer.get_pixel((x+sample_rate) as u32, y as u32).0[0] as i32;
            let top = img_buffer.get_pixel(x as u32, (y-sample_rate) as u32).0[0] as i32;
            let bottom = img_buffer.get_pixel(x as u32, (y+sample_rate) as u32).0[0] as i32;
            
            // 计算梯度
            let dx = (left - right).abs();
            let dy = (top - bottom).abs();
            let gradient = (dx + dy) as f32 / 2.0;
            
            // 使用阈值检测边缘
            if gradient > 20.0 {
                edge_pixels += 1;
            }
        }
    }
    
    // 计算边缘密度(边缘像素占比) - 修复类型
    let sampled_pixels = ((width as usize / sample_rate) * (height as usize / sample_rate)) as f32;
    edge_pixels as f32 / sampled_pixels
}

// 计算图像的颜色多样性 - 修复可能的类型问题
fn calculate_color_diversity(img: &DynamicImage) -> f32 {
    // 使用颜色直方图来评估多样性
    let (width, height) = img.dimensions();
    let rgb_img = img.to_rgb8();
    
    // 采样率和量化级别
    let sample_rate = if width * height > 1_000_000 { 7usize } else { 3usize };
    let quantization = 32; // 将每个颜色通道量化为32个级别
    
    // 用于统计颜色直方图
    let mut color_counts = std::collections::HashMap::new();
    
    // 采样图像颜色
    for y in (0..height as usize).step_by(sample_rate) {
        for x in (0..width as usize).step_by(sample_rate) {
            let pixel = rgb_img.get_pixel(x as u32, y as u32).0;
            
            // 颜色量化
            let r = (pixel[0] as usize) * quantization / 256;
            let g = (pixel[1] as usize) * quantization / 256;
            let b = (pixel[2] as usize) * quantization / 256;
            
            let color_key = (r, g, b);
            *color_counts.entry(color_key).or_insert(0) += 1;
        }
    }
    
    // 不同颜色的数量
    let unique_colors = color_counts.len();
    let max_colors = quantization * quantization * quantization;
    
    // 归一化的颜色多样性
    (unique_colors as f32 / max_colors as f32).min(1.0)
}

// 处理单张图片
fn process_single_image(base64_data: String, mut options: ImageOptions) -> Result<ProcessResult, ImageProcessError> {
    // 解码base64数据
    let data = base64_data.split(",").nth(1).unwrap_or(&base64_data);
    let image_data = general_purpose::STANDARD
        .decode(data)
        .map_err(|e| ImageProcessError::DecodeError(format!("Failed to decode base64: {}", e)))?;
    
    // 加载图片
    let img = image::load_from_memory(&image_data)
        .map_err(|e| ImageProcessError::IoError(format!("Failed to load image: {}", e)))?;
    
    // 调整大小（如果需要）
    let mut img = resize_image_if_needed(img, options.max_width, options.max_height);
    
    if options.strip_metadata {
        // 移除元数据
        img = strip_metadata(img);
    }
    
    if options.optimize {
        // 根据图片特征选择最佳压缩参数
        options.quality = calculate_optimal_quality(&img);
    }
    
    // 获取图片尺寸
    let (width, height) = img.dimensions();
    
    // 确定输出格式和质量
    let output_format = match options.format.to_lowercase().as_str() {
        "jpeg" | "jpg" => image::ImageOutputFormat::Jpeg(options.quality),
        "png" => image::ImageOutputFormat::Png,
        "gif" => image::ImageOutputFormat::Gif,
        "webp" => image::ImageOutputFormat::WebP,
        "png-to-webp" => {
            // 检查原始图片格式是否为PNG
            if let Ok(format) = image::guess_format(&image_data) {
                if format == ImageFormat::Png {
                    image::ImageOutputFormat::WebP
                } else {
                    return Err(ImageProcessError::InvalidFormat("只能将PNG格式的图片转换为WebP格式".to_string()));
                }
            } else {
                return Err(ImageProcessError::InvalidFormat("无法识别图片格式".to_string()));
            }
        },
        _ => image::ImageOutputFormat::Jpeg(options.quality),
    };
    
    // 编码图片
    let mut buffer = Vec::new();
    img.write_to(&mut Cursor::new(&mut buffer), output_format)
        .map_err(|e| ImageProcessError::EncodeError(format!("Failed to encode image: {}", e)))?;
    
    // 转换为base64
    let base64_data = format!(
        "data:image/{};base64,{}",
        format_to_mime(&options.format),
        general_purpose::STANDARD.encode(&buffer)
    );
    
    // 确保在PNG转WebP的情况下返回正确的格式
    let final_format = if options.format == "png-to-webp" {
        "webp".to_string()
    } else {
        options.format.clone()
    };

    Ok(ProcessResult {
        data: base64_data,
        format: final_format,
        size: buffer.len() as u32,
        width,
        height,
    })
}

// 根据需要调整图片大小
fn resize_image_if_needed(img: DynamicImage, max_width: Option<u32>, max_height: Option<u32>) -> DynamicImage {
    let (width, height) = img.dimensions();
    
    match (max_width, max_height) {
        (Some(max_w), Some(max_h)) => {
            if width > max_w || height > max_h {
                let ratio_w = max_w as f32 / width as f32;
                let ratio_h = max_h as f32 / height as f32;
                let ratio = ratio_w.min(ratio_h);
                
                let new_width = (width as f32 * ratio) as u32;
                let new_height = (height as f32 * ratio) as u32;
                
                img.resize(new_width, new_height, image::imageops::FilterType::Lanczos3)
            } else {
                img
            }
        },
        (Some(max_w), None) => {
            if width > max_w {
                let ratio = max_w as f32 / width as f32;
                let new_height = (height as f32 * ratio) as u32;
                
                img.resize(max_w, new_height, image::imageops::FilterType::Lanczos3)
            } else {
                img
            }
        },
        (None, Some(max_h)) => {
            if height > max_h {
                let ratio = max_h as f32 / height as f32;
                let new_width = (width as f32 * ratio) as u32;
                
                img.resize(new_width, max_h, image::imageops::FilterType::Lanczos3)
            } else {
                img
            }
        },
        (None, None) => img,
    }
}

// 将格式字符串转换为MIME类型
fn format_to_mime(format: &str) -> String {
    match format.to_lowercase().as_str() {
        "jpg" | "jpeg" => "jpeg".to_string(),
        "png" => "png".to_string(),
        "gif" => "gif".to_string(),
        "webp" | "png-to-webp" => "webp".to_string(),
        _ => "jpeg".to_string(),
    }
}


#[cfg_attr(mobile, tauri::mobile_entry_point)]
pub fn run() {
    tauri::Builder::default()
        .plugin(tauri_plugin_opener::init())
        .invoke_handler(tauri::generate_handler![app_process_image])
        .run(tauri::generate_context!())
        .expect("error while running tauri application");
}